<?php require_once('libs/View.php');

/**
* 
*/
class Controller {

	function __construct() 
	{
		$this->view = new View();
	}
}	