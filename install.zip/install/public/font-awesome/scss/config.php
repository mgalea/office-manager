<?php
/*This name will represent title in auto generated mail*/
define('NAME', 'Klinical Health care');
/*Domain name like www.yourdomain.com*/
define('URL', 'http://mahendra-clinic.azurewebsites.net/');
define('URL_ADMIN', 'http://mahendra-clinic.azurewebsites.net/admin/');
/*Support email*/
define('SITEEMAIL', 'support@pepdev.com');
/*Clinic address*/
define('ADDRESS', 'C 204 Natasha Hill View NIBM Road, Kondhwa Bk Pune');


/*Application Address*/
define('DIR_ROUTE', 'index.php?route=');
define('DIR', 'D:/home/site/wwwroot/');
define('DIR_ADMIN', 'D:/home/site/wwwroot/admin/');
define('DIR_APP', 'D:/home/site/wwwroot/app/');
define('DIR_BUILDER', 'D:/home/site/wwwroot/builder/');


/** SMTP Credentials **/
define('SMTP_HOST', '');
define('SMTP_USERNAME', '');
define('SMTP_PASSWORD', '');
define('SMTP_PORT', '');


/** MySQL settings - You can get this info from your web host **/
/*MySQL database host*/
define('DB_HOSTNAME', 'mahendra-clinic.mysql.database.azure.com');
/*MySQL database username*/
define('DB_USERNAME', 'clinical@mahendra-clinic');
/*MySQL database password*/
define('DB_PASSWORD', 'Mahi123@');
/*MySQL database Name*/
define('DB_DATABASE', 'clinical');
/*Table Prefix*/
define('DB_PREFIX', 'zz_');


define('AUTH_KEY', 'aVDXwwW}61{q91sDZiLD(2er?XXC~2q*ARa#5&#bhy23hDCq%SRB9H?(S-(<GXE7');
define('LOGGED_IN_SALT', 'fB8{Y2~WN>fp&;krL>{C?orVEhQuYz{I8Y|g5yK3>Vt4CQh0slqszIsmKs9Jj0K-');
define('TOKEN', 'RON#HL1eWg|-lrWh7z<mDx%XAO32tKA0IHt8UH%N)#<vehOPI)OrKI;*56y#Yu(4');
define('TOKEN_SALT', '#-jJx%y9b1<z8~xu3vKd8)7T(Pb)5qALz&eobhf8Iz1*}TimcU4zc70yif~zsuDw');
